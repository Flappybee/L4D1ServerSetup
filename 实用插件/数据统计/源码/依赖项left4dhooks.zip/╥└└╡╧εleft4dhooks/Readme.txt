原地址:
https://forums.alliedmods.net/showthread.php?t=321696
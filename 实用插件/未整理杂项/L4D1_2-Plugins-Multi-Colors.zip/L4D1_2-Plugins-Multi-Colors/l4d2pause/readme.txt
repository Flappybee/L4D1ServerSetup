Allows admins to force the game to pause, only adm can unpause the game.

-ChangeLog-
v1.3
-Remake code
-Only Adm can pause and unpause the gmae
-Chat Color during pause
-Fixed compatibility with plugin "lfd_noTeamSay" v2.2+ by bullet28, HarryPotter

v0.2.1
-Original Post-
https://forums.alliedmods.net/showthread.php?t=110029

-Require-
1. [INC] Multi Colors: https://forums.alliedmods.net/showthread.php?t=247770

-Related Plugin: 
1. lfd_noTeamSay: https://github.com/fbef0102/L4D1_2-Plugins/tree/master/lfd_noTeamSay

-ConVar-
cfg\sourcemod\l4d2pause.cfg
// Only allow the game to be paused by the forcepause command(Admin only).
l4d2pause_forceonly "1"

-Command-
** Adm forces the game to pause/unpause (Admin Flag: ADMFLAG_ROOT)
	sm_forcepause



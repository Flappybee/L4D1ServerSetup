Please be Quiet! Block unnecessary chat or announcement

-Detail-
1.Block name change announcement
2.Block server convars change announcement
3.Block chat with '!' or '/'

-Changelog-
v1.6
-Remake code
-Remove all convars

v1.33.7
-Original Post: https://github.com/SirPlease/L4D2-Competitive-Rework/blob/master/addons/sourcemod/scripting/bequiet.sp

-Convar-
None
Executes cfg file on server startup

-cfg file on server startup-
cfg/server_startup.cfg

-ConVar-
//Config that gets executed on server start. (Empty=Disable)
server_loader "server_startup.cfg"

Display Tank HP status on his head

-Version-
v1.3
Fork by Harry

v1.1.3
-Original Post by Marttt: https://forums.alliedmods.net/showthread.php?t=330370

-Require-
1. left4dhooks: https://forums.alliedmods.net/showthread.php?p=2684862

-Convars-
None

-Command-
None

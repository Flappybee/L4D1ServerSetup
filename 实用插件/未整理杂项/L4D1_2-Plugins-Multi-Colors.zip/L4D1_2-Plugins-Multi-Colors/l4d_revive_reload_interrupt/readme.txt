Reviving cancels reloading to fix that weapon has jammed and misfired (stupid bug exists for more than 10 years)
(解決裝子彈的時候拯救隊友會卡彈的問題)

Video:
Left 4 Dead Revive Reload Bug - jam and misfire
https://youtu.be/f1I-CaU6oXI

Left 4 Dead 2 Revive Reload Bug - Reload Twice
https://youtu.be/QBAkP6W46Gg

-ChangeLog-
2022 @ HarryPotter
v1.0
AlliedModders Post: https://forums.alliedmods.net/showthread.php?t=338878

-Require-
None

-Convar-
None

-Command-
None

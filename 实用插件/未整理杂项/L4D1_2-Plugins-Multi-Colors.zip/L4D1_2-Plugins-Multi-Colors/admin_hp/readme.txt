Adm type !givehp to set survivor team full health

-Changelog-
v2.6
-Remake code

-ConVar-
None

-Command-
"Restore all survivors full hp"
!hp
!givehp
Announces hunter pounces to the entire server

-Changelog-
v1.8
-Remake code
-The minimum amount of damage required to instantly kill survivor.

v1.5
Original Post by n0limit: https://forums.alliedmods.net/showthread.php?t=93605

-Require-
1. [INC] Multi Colors: https://forums.alliedmods.net/showthread.php?t=247770

-ConVar-
// Caps the displayed pounce damage to the maximum able to be dealt.
pounceannounce_capdamage "0"

// Announces the pounce to 0: chatbox, 1: center chat.
pounceannounce_centerchat "0"

// The minimum amount of damage required to instantly kill survivor.(0=Off)
pounceannounce_killdamage "0"

// The minimum amount of damage required to announce the pounce
pounceannounce_minimum "0"

// Show the distance the hunter traveled for the pounce.
pounceannounce_showdistance "3"

-Command-
None




when player in spec team, add prefix

-Convar-
cfg\sourcemod\l4d_spectator_prefix.cfg
// 0=Plugin off, 1=Plugin on.
l4d_spectator_prefix_allow "1"

// Turn on the plugin in these game modes, separate by commas (no spaces). (Empty = all).
l4d_spectator_prefix_modes ""

// Turn off the plugin in these game modes, separate by commas (no spaces). (Empty = none).
l4d_spectator_prefix_modes_off ""

// Turn on the plugin in these game modes. 0=All, 1=Coop, 2=Survival, 4=Versus, 8=Scavenge. Add numbers together.
l4d_spectator_prefix_modes_tog "0"

// Determine your preferred type of Spectator Prefix
l4d_spectator_prefix_type "(S)"

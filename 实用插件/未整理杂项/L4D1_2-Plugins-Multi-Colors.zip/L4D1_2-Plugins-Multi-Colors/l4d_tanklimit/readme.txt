limit tank in server

-Changelog-
v1.2

-ConVar-
//maximum of tanks in server
z_tank_limit "3"

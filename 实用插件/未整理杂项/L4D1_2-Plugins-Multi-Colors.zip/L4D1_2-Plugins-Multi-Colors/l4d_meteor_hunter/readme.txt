high pounces cause meteor strike

-ChangeLog-
v1.5
-Remake Code
-Add Convars

v1.0
-original Post: https://forums.alliedmods.net/showthread.php?p=2712447

-ConVar-
// 0=Plugin off, 1=Plugin on.
l4d_meteor_hunter_allow "1"

// Damage caused by meteor strike.
l4d_meteor_hunter_damage "15.0"

// Hunter Pounce Distance needed to trigger meteor strike.
l4d_meteor_hunter_distance "800"

// Turn on the plugin in these game modes, separate by commas (no spaces). (Empty = all).
l4d_meteor_hunter_modes ""

// Turn off the plugin in these game modes, separate by commas (no spaces). (Empty = none).
l4d_meteor_hunter_modes_off ""

// Turn on the plugin in these game modes. 0=All, 1=Coop, 2=Survival, 4=Versus, 8=Scavenge. Add numbers together.
l4d_meteor_hunter_modes_tog "0"

// How much force is applied to the survivor (meteor strike).
l4d_meteor_hunter_power "300"

// Hunter meteor strike range.
l4d_meteor_hunter_range "200"

// Vertical force multiplier (meteor strike).
l4d_meteor_hunter_vertical_mult "1.5"



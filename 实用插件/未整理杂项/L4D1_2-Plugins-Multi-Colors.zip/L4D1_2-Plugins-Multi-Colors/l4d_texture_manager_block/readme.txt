Kicks out clients who are potentially attempting to enable mathack

-Changelog-
v1.6

-Credit-
"Sir, Visor" - l4d_texture_manager_block 
(https://github.com/Attano/L4D2-Competitive-Framework/blob/master/addons/sourcemod/scripting/l4d_texture_manager_block.sp)
"NightTime & extrav3rt" - execlub_mathack_detection
(https://forums.alliedmods.net/showthread.php?p=2580578)

-Catchack command block-
1. mat_texture_list
2. mat_queue_mode
3. mat_hdr_level
4. mat_postprocess_enable
5. r_drawothermodels
6. l4d_bhop from l4dbhop.dll (l4d1 only)
7. l4d_bhop_autostrafe from l4dbhop.dll (l4d1 only)
8. cl_fov (l4d1 only)

-Convar-
"l4d1_penalty", "1", "1 - kick clients, 0 - record players in log file(sourcemod/logs/mathack_cheaters.txt), other value: ban minutes"

-Command-
Nonoe
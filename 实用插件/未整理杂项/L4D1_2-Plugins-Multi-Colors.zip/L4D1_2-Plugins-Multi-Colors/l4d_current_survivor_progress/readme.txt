Print survivor progress in flow percents

-Changelog-
v2.4
-Remake Code
-Support Coop/Versus/Realism

-Require-
1. left4dhooks: https://forums.alliedmods.net/showthread.php?p=2684862
2. [INC] Multi Colors: https://forums.alliedmods.net/showthread.php?t=247770

-ConVar-
None

-Command-
 *Print survivor progress in flow percents
	 sm_cur
	 sm_current
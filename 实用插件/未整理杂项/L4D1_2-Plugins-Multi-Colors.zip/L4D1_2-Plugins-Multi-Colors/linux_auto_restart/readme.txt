make server restart (Force crash) when the last player disconnects from the server

-ChangeLog-
v2.2

Recommended for
1. LINUX
2. WINDOWS with HLSM

-ConVar-
// If you have Accelerator extension, you need specify here order number of this extension in the list: sm exts list
liunx_auto_restart_unload_ext_num "03"

-Command-
None
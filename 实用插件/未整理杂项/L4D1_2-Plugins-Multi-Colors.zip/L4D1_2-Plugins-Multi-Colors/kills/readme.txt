Show statistics of surviviors (kill S.I, C.I. and FF)on round end
(擊殺殭屍與特殊感染者統計)

-Changelog-
v1.6
-Remake code
-Translation support
-Support versus/coop/realism

-Require-
[INC] Multi Colors: https://forums.alliedmods.net/showthread.php?t=247770

-ConVar-
None

-Command-
!kills
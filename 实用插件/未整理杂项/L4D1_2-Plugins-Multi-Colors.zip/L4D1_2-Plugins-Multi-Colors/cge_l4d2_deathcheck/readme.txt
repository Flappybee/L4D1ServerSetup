Prevents mission loss(Round_End) until all human players have died.

-ChangeLog-
v2.1
-Remake code
-fixed double round end issue when map change

v1.5.6
-original post: https://forums.alliedmods.net/showthread.php?t=142432

-Notice-
The plugin does not work until survivor has left the saferoom
倖存者出去安全區域之後此插件才會生效

-ConVar-
// 0: Disable plugin, 1: Enable plugin
deathcheck "1"

// 0: Mission will be lost if all human players have died, 1: Bots will continue playing after all human players are dead and can rescue them
deathcheck_bots "1"
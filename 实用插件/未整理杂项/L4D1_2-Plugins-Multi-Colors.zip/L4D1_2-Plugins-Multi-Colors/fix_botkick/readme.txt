Fixed no Survivor bots issue or too many Survivor bots issue after map loading.


-Usually this bug happens when using readyup plugin.

-Command-
"sm_botfix", "trying to fix wrong numbers of survivor bots in server."

-Related Command-
"survivor_limit", "Max # of survivors"
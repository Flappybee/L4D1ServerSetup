Let's play a game, Duel 決鬥!!

-Changelog-
v1.3
-Remake

v1.0
-Created by Harry

-ConVar-
// Time delay in seconds between allowed coinflips. Set at -1 if no delay at all is desired.
coinflip_delay "1"

-command-
!roll <number>, !picknumber <number> (擲骰子)
!code <number> (終極密碼)
!coin, !flip,!coinflip (猜硬幣)

Displays chat advertisements when specified text is said in player chat.
See chat_responses.jpg

-Require-
1. [INC] Multi Colors: https://forums.alliedmods.net/showthread.php?t=247770

-ConVar-
None

-Command-
Nonoe
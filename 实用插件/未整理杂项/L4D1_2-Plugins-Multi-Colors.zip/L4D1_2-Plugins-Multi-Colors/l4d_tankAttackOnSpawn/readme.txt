Forces AI tank to leave stasis and attack while spawn in coop.

-Changelog-
v0.3
-Remake Code
-Add ConVar

v0.1
-Original Post: https://forums.alliedmods.net/showpost.php?p=2679726&postcount=13

-ConVar-
cfg/sourcemod/l4d_tankAttackOnSpawn.cfg
// 0=Plugin off, 1=Plugin on.
l4d_tankAttackOnSpawn_allow "1"

// Tank chases survivors in seconds after tank spawns in coop
l4d_tankAttackOnSpawn_seconds "3.0"

-Command-
None
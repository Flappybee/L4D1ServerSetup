Adds Friendly Fire Announcements (who kills teammates)

-Changelog-
v1.7
-Remake Code

v1.4
-Original Post: https://forums.alliedmods.net/showthread.php?p=902507

-Require-
1. left4dhooks: https://forums.alliedmods.net/showthread.php?p=2684862
2. [INC] Multi Colors: https://forums.alliedmods.net/showthread.php?t=247770

-ConVar-
cfg\sourcemod\l4dffannounce.cfg
// Enable Announcing Friendly Fire
l4d_ff_announce_enable "1"

// Changes how ff announce displays FF damage (1:In chat; 2: In Hint Box; 3: In center text)
l4d_ff_announce_type"1"

-Command-
None

Skeet Announce Edition, and save record to data/skeet_database.txt

-Changelog-
v2.2
Autor: thrillkill
Edited: JNC
Improve: Harry

-Convar-
cfg\sourcemod\skeet_database.cfg
// Record 1v1 skeet database in 1v1 mode.
skeet_database_1v1_seprate "1"

// Count AI Hunter also?[1: Yes, 0: No]
skeet_database_ai_hunter_enable "0"

// Announce skeet/shots in chatbox when someone skeets.
skeet_database_announce "0"

// Only count 'One Shot' skeet?[1: Yes, 0: No]
skeet_database_announce_oneshot "1"

// Enable this plugin?
skeet_database_enable "1"

// Turn on the plugin in these game modes. 0=All, 1=Coop, 2=Survival, 4=Versus. Add numbers together.
skeet_database_modes_tog "4"

// Numbers of Survivors required at least to enable this plugin
top_skeet_survivors_required "4"

-Command-
** Show your current skeet statistics and rank.
	"sm_skeets"

** Show TOP 5 players in statistics.
	"sm_top5"

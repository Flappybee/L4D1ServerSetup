Show damage done to S.I. by survivors

-Changelog-
v2.0
-Remake code

v1.6
-Original Post: https://forums.alliedmods.net/showthread.php?t=123811?t=123811

-Convars-
// If 1, Enables this plugin.
sm_assist_enable "1"

// Turn on the plugin in these game modes, separate by commas (no spaces). (Empty = all).
sm_assist_modes ""

// Turn off the plugin in these game modes, separate by commas (no spaces). (Empty = none).
sm_assist_modes_off ""

// Turn on the plugin in these game modes. 0=All, 1=Coop, 2=Survival, 4=Versus, 8=Scavenge. Add numbers together.
sm_assist_modes_tog "0"

// If 1, only show damage done to Tank.
sm_assist_tank_only "1"



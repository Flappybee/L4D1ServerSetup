Redirecting all 'say_team' messages to 'say'

-ChangeLog-
v2.2
-Remake Code
-Fixed compatibility with plugin "sm_regexfilter" 1.3 by Twilight Suzuka, HarryPotter

v1.0
-Original Post: https://forums.alliedmods.net/showthread.php?p=2691314

-ConVar-
// Messages starting with this will be ignored, separate by , symbol
noteamsay_ignorelist "!,/,@"

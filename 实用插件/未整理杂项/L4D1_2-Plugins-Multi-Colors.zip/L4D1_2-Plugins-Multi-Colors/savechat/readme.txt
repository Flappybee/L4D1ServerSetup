Records player chat messages to a file

-Save Chat File-
server_port_chat_year_month_day.txt in -left4dead\addons\sourcemod\logs\chat

-Changelog-
v1.5
-Remake code
-record steam id、ip

v1.2.1
-Original Post: https://forums.alliedmods.net/showthread.php?p=1071512

-ConVar-
// Record player Steam ID and IP address
sc_record_detail "1"

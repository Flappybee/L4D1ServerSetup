Show what mode is it now on server name(support any Language) with txt file

-Example-
1. modify configs\hostname\server_hostname.txt: [中文亞洲] Asia L4D 惡靈勢力中文房名
2. write convar: l4d_current_mode "Harry's mod"
3. The Server name will be "[中文亞洲] Asia L4D 惡靈勢力中文房名 (Harry's mod)" on map change or restart server

-ChangeLog-
v1.7
- Fixed leaking 1 handle.

-ConVar-
"l4d_current_mode", "", "League notice displayed on server name"

-Command-
None

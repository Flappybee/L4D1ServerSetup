Fixes issue when a bot die, his IDLE player become fully spectator rather than take over dead bot in 4+ survivors games

-AlliedModder-
4+ Survivor AFK Fix Remake: https://forums.alliedmods.net/showpost.php?p=2772050&postcount=54

-Changelog-
v1.1
-Remove lots of unuse code
-Original Post: https://forums.alliedmods.net/showthread.php?t=132409

-Require-
1. left4dhooks: https://forums.alliedmods.net/showthread.php?p=2684862

-Related plugin (No conflict)-
1. Survivor_AFK_Fix: https://forums.alliedmods.net/showthread.php?p=2714236
2. Survivor Identity Fix for 5+ Survivors (Shadowysn version): https://forums.alliedmods.net/showpost.php?p=2718792&postcount=36
3. AFK and Join Team Commands Improved: https://forums.alliedmods.net/showpost.php?p=2719702&postcount=32

-ConVar-
None

-Command-
None




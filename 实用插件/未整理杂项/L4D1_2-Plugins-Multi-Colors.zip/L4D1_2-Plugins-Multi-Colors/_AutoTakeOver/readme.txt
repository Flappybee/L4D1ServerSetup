Auto Takes Over an alive free bot UponDeath or OnBotSpawn or OnBotReplace in 5+ survivors

-ChangeLog-
// 2017 @ Lux
// 2022 @ Harry
v2.3
AlliedModders Post: https://forums.alliedmods.net/showpost.php?p=2773718&postcount=16
-Remake Code
-Add more convars
-Use left4dhooks functions to take over free bots.

v2.0
-Original Post: https://forums.alliedmods.net/showthread.php?t=293770

-Require-
1. left4dhooks: https://forums.alliedmods.net/showthread.php?p=2684862

-Convar-
cfg\sourcemod\_auto_take_over.cfg
// If 1, you will skip idle state in survival/coop/realism.
ato_coop_take_over_method "0"

// 0=Plugin off, 1=Plugin on.
ato_enabled "1"

// If 1, when a survivor bot spawns or replaces a player, any dead survivor player will take over bot. (Random choose dead survivor)
ato_take_over_OnBotSpawn_dead "1"

// If 1, when a survivor bot spawns or replaces a player, any free spectator player will take over bot. (Random choose free spectator)
ato_take_over_OnBotSpawn_spectator "0"

// If 1, when a player joins server, he will take over an alive free bot if any. (Random choose bot)
ato_take_over_OnJoinServer "1"

// If 1, when a survivor player dies, he will take over an alive free bot if any. (Random choose bot)
ato_take_over_UponDeath "1"

-Command-
None

The witch turns back if nearby survivor scares her behind

Fixes this bullshit: https://www.youtube.com/watch?v=4hDpyzwzahY

-Changelog-
v1.2
AlliedModder Post: https://forums.alliedmods.net/showpost.php?p=2770549&postcount=124

-Related Plugin: 
1. Witch fixes[Left 4 Fix]: https://forums.alliedmods.net/showthread.php?t=315481
2. witch_target_override: https://github.com/fbef0102/L4D1_2-Plugins/tree/master/witch_target_override

-ConVar-
None

-Command-
None

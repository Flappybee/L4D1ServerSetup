Block rocket jump exploit (with grenade launcher/vomitjar/pipebomb/molotov/common/spit/rock/witch)

-Changelog-
v1.4
- Remake Code
- molotov
- pipebomb
- vomitjar
- grenade launcher
- spitter projectile
- tank rock
- common infected
- witch

v1.1
-Original Post by DJ_WEST: https://forums.alliedmods.net/showthread.php?t=122371

-Convar-
None

-Command-
None



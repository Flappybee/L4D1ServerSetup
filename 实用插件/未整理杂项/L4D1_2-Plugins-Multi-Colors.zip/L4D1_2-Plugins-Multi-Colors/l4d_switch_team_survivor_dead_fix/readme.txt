Fixed a bug that exists over 12 years in l4d1/2 (fuck you valve), sometimes infected player switchs team to survivor, the survivor gets incapped/killed instantly

This video shows you the problem: https://youtu.be/jIPvR0MJI1I

IMPORTANT!!!
This plugins is OBSOLETE, use remove_touch_links instead for better fix.
(https://github.com/shqke/sp_public/tree/master/remove_touch_links)

-ChangeLog-
v1.0
AlliedModders Post: https://forums.alliedmods.net/showthread.php?t=336135

-ConVar-
None

-Command-
None


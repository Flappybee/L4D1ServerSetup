Blocks the stupid griefers who spam vocalize commands throughout campaigns.

-Original Post-
https://forums.alliedmods.net/showthread.php?t=83432

-Require-
A dedicated server.
This plugins doesn't work in listen server.

-ConVar-
// Enable/Disable Admin Immunity to Penalties [0 = FALSE, 1 = TRUE]
sm_vocalize_guard_adminimmune "1"

// Duration of Ban [0 = KICKS PLAYER]
sm_vocalize_guard_bantime "0"

// Enable/Disable L4D Vocalize Guardian [0 = FALSE, 1 = TRUE]
sm_vocalize_guard_enabled "1"

// Delay before a player can call another Vocalize command [0 = DISABLED]
sm_vocalize_guard_vdelay "10"

// Max Vocalize Spam Calls Allowed [0 = NO LIMIT]
sm_vocalize_guard_vlimit "9999"




Fixes a handful of silly Tickrate bugs including door speed.

Original post: https://github.com/Attano/L4D2-Competitive-Framework/blob/master/addons/sourcemod/scripting/TickrateFixes.sp
I convert all codes to sourcemod v1.10 new syntax.

//ConVar
"l4d_pistol_delay_dualies", "0.1", "Minimum time (in seconds) between dual pistol shots"
"l4d_pistol_delay_single", "0.2", "Minimum time (in seconds) between single pistol shots"
"l4d_pistol_delay_incapped", "0.3", "Minimum time (in seconds) between pistol shots while incapped"
"tick_door_speed", "1.3", "Sets the speed of all prop_door entities on a map. 1.05 means = 105% speed"

Soul of the dead survivor flies away to the afterlife

-ChangeLog-
//Dragokas @ 2019
//Harry @ 2022
v1.7
- Remove soul when player changes team.
- Remove CPR

v1.6
-Original Post by Dragokas: https://forums.alliedmods.net/showthread.php?p=2670588

-Convars-
cfg\sourcemod\l4d_death_soul.cfg
// 0=Plugin off, 1=Plugin on.
l4d_death_soul_allow "1"

-Command-
None
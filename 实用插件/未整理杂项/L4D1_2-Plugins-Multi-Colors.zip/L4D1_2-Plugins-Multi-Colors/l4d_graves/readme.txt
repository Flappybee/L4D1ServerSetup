When a survivor die, on his body appear a grave.

-ChangeLog-
AlliedModders Post: https://forums.alliedmods.net/showpost.php?p=2771370&postcount=24
v1.3
-Remake Code
-Random Color
-Glow Range
-Safely remvoe grave

v1.1.1
-Original Post by Dartz8901: https://forums.alliedmods.net/showthread.php?t=313063

-Convars-
cfg\sourcemod\l4d_graves.cfg
// How long will it take for the grave to spawn.
l4d_graves_delay "5.0"

// Enable or disable this plugin.
l4d_graves_enable "1"

// Turn glow On or Off.
l4d_graves_glow "1"

// L4D2 Only, RGB Color - Change the render color of the glow. Values between 0-255. [-1 -1 -1: Random]
l4d_graves_glow_color "-1 -1 -1"

// L4D2 Only, Change the glow range. 
l4d_graves_glow_range "1500"

// Number of points of damage to take before breaking. (In L4D2, 0 means don't break)
l4d_graves_health "1500"

// Enables or disables the solidity of the grave.
l4d_graves_not_solid "0"

-Command-
None

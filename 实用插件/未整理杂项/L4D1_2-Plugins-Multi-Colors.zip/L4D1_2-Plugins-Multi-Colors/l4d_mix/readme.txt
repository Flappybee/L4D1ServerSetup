L4D1/2 Mix

-ChangeLog-
1.0 Credits
	- KaiN - for request and the original idea	
	- ZenServer -[ Mix ]- - for the original plugin
	- JOSHE GATITO SPARTANSKII >>> (Ex Aya Supay) - for writing  plugin again and add new commands. 
	- Harry - fix error, optimize codes, new sourcemod syntax, and handle exception
	
1.1 (26-03-2019)
	- Initial release.
	- Cleared old code, converted to new syntax and methodmaps.	

1.2 (13-04-2019)
	- fix error, optimize codes, and handle exception
	
1.3 (15-04-2020)
	- 強制換隊

1.4 (11-10-2020)
	- Compiled .smx plugin is now compiled with SourceMod version 1.10

1.5 (15-5-2021)
	- Add A-BB-A-B-A

1.6 (17-5-2021)
	- Hide ReadyUp Hud if Ready Up plugin is available

1.7 (8-3-2022)
	- fix client not in game error

1.8 (21-10-2022)
	- Compiled .smx plugin is now compiled with SourceMod version 1.11

-Require-
1. left4dhooks: https://forums.alliedmods.net/showthread.php?p=2684862
2. [INC] Multi Colors: https://forums.alliedmods.net/showthread.php?t=247770

-Convars-
cfg\sourcemod\l4d_mix_player.cfg
// 0 = ABABAB | 1 = ABBAAB | 2 = ABBABA
l4d_mix_select_order "1"

-Command-
None